/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package APAC2Interfaz;

/**
 *
 * @author ionut
 */
import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

class connectionManager {

    String server;
    String port;
    String user;
    String pass;
    Connection laConnexio = null;

    connectionManager() {
        this.server = "localhost";
        this.port = "3308";
        this.user = "root";
        this.pass = "root";

    }

    connectionManager(String server, String port, String user, String pass) {
        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;

    }

    public Connection connectDBMS() {
        // TO-DO:   Crea una connexió a la base de dades,
        //          i retorna aquesta o null, si no s'ha pogut connectar.

        // Passos:
        // 1. Carreguem el driver JDBC
        // 2. Crear la connexió a la BD
        // 3. Retornar la connexió
        // Recordeu el tractament d'errors
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String connectionUrl = "jdbc:mysql://" + server + ":" + port
                    + "?useUnicode=true&characterEncoding=UTF-8"
                    + "&allowMultiQueries=true"
                    + "&user=" + user
                    + "&password=" + pass;

            laConnexio = DriverManager.getConnection(connectionUrl);

            return laConnexio;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return laConnexio;
    }

    public String showInfo() {
        String datos = "";
        try {
            // TO-DO: Mostra la informació del servidor a partir de les metadades
            // - Nom del SGBD
            // - Driver utilitzat
            // - URL de connexió
            // - Nom de l'usuari connectat

            // Recordeu el tractament d'errors
            DatabaseMetaData dbmd = laConnexio.getMetaData();

            datos = new String(String.format("%-15s"
                    + " %-15s "
                    + "%-15s "
                    + "%-15s ",
                    " " + dbmd.getDriverName() + " : \n",
                    " " + dbmd.getDatabaseProductName() + "\n",
                    " " + dbmd.getURL() + "\n",
                    " " + dbmd.getUserName() + "\n"
            ));

            return datos;
        } catch (SQLException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }

    public void importScript(String script) {

        Statement st = null;
        try {
            st = laConnexio.createStatement();

            if (script.length() > 0) {
                st.executeUpdate(script);
            }
            if (st != null) {
                st.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        } finally {

        }

    }

    public ResultSet showDatabases() {
        ResultSet rs = null;
        try {
            rs = laConnexio.prepareStatement("SHOW databases").executeQuery();

            return rs;

        } catch (SQLException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rs;
    }

}
