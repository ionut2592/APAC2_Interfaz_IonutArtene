package APAC2Interfaz;

import java.sql.*;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

class databaseManager {

    String server;
    String port;
    String user;
    String pass;
    String dbname;
    Connection cone = null;
    DatabaseMetaData dbmd;
    ResultSet rs = null;
    DefaultTableModel modelo = null;
    DefaultTableModel modelo2 = null;
    ArrayList<String> tipo;
    ArrayList<String> nullable2;

    databaseManager() {

        this.server = "localhost";
        this.port = "3308";
        this.user = "root";
        this.pass = "root";
        this.dbname = "";
    }

    databaseManager(String server, String port, String user, String pass, String dbname) {

        this.server = server;
        this.port = port;
        this.user = user;
        this.pass = pass;
        this.dbname = dbname;

    }

    public Connection connectDatabase() {

        // TO-DO:   Crea una connexió a la base de dades,
        //          i retorna aquesta o null, si no s'ha pogut connectar.
        // Passos:
        // 1. Carreguem el driver JDBC
        // 2. Crear la connexió a la BD
        // 3. Retornar la connexió
        // Recordeu el tractament d'errors
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            String connectionUrl = "jdbc:mysql://" + server + ":" + port + "/" + dbname
                    + "?useUnicode=true&characterEncoding=UTF-8"
                    + "&user=" + user
                    + "&password=" + pass;

            cone = DriverManager.getConnection(connectionUrl);
            try {
                this.dbmd = cone.getMetaData();
            } catch (SQLException ex) {
                Logger.getLogger(databaseManager.class.getName()).log(Level.SEVERE, null, ex);
            }

            return cone;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(databaseManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(databaseManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cone;
    }

    public ResultSet showTables() {
        // TO-DO: Mostra un llistat amb les taules de la base de dades

        // Passos:
        // 1. Establir la connexió a la BD
        // 2. Obtenir les metadades
        // 3. Recórrer el resultset resultant mostrant els resultats
        // 4. Tancar la connexió
        // Recordeu el tractament d'errors
        try {
            rs = cone.prepareStatement("SHOW tables").executeQuery();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(connectionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;

    }

    public void insertIntoTable(String table) {
        // TO-DO: Afig informació a la taula indicada

        // Passos
        // 1. Estableix la connexió amb la BD
        // 2. Obtenim les columnes que formen la taula (ens interessa el nom de la columna i el tipus de dada)
        // 3. Demanem a l'usuari el valor per a cada columna de la taula
        // 4. Construim la sentència d'inserció a partir de les dades obtingudes
        //    i els valors proporcionats per l'usuari
        // Caldrà tenir en compte:
        // - Els tipus de dada de cada camp
        // - Si es tracta de columnes generades automàticament per la BD (Autoincrement)
        //   i no demanar-les
        // - Gestionar els diferents errors
        // - Si la clau primària de la taula és autoincremental, que ens mostre el valor d'aquesta quan acabe.
    }

    public void showDescTable(String table) {
        // TO-DO: Mostra la descripció de la taula indicada,
        //        mostrant: nom, tipus de dada i si pot tindre valor no nul
        //        Informeu també de les Claus Primàries i externes
        modelo = new DefaultTableModel();
        modelo2 = new DefaultTableModel();
        try {
            ResultSet rspk = dbmd.getPrimaryKeys(dbname, null, table);
            ArrayList<String> pks = new ArrayList<String>();
            ArrayList<String> tipo = new ArrayList<>();
            ArrayList<String> nullable2 = new ArrayList<>();
            ArrayList<String> autoinc = new ArrayList<>();

            while (rspk.next()) {
                pks.add(rspk.getString(4));
            }

            rspk.close();

            ResultSet rsfk = dbmd.getImportedKeys(dbname, null, table);
            ArrayList<String> fks = new ArrayList<String>();
            ArrayList<String> fksExt = new ArrayList<String>();

            while (rsfk.next()) {
                fks.add(rsfk.getString(8)); // Guarda el camp de la Clau Externa
                fksExt.add(rsfk.getString(3)); // Guarda la taula a que fa referéncia
            }

            ResultSet columnes = dbmd.getColumns(dbname, null, table, null);

            while (columnes.next()) {
                String columnName = columnes.getString(4);
                modelo2.addColumn(columnName);
                if (pks.contains(columnName) || fks.contains(columnName)) {

                } else {
                    modelo.addColumn(columnName);
                    //modelo2.addColumn(columnName);

                }

                if (pks.contains(columnName)) {
                    columnName += "(PK)";
                    modelo.addColumn(columnName);
                    //modelo2.addColumn(columnName);

                }

                if (fks.contains(columnName)) {
                    columnName += "(FK) -->" + fksExt.get(fks.indexOf(columnName));
                    modelo.addColumn(columnName);
                    //modelo2.addColumn(columnName);
                }

                String tipus = columnes.getString(6);
                tipo.add(tipus);
                String nullable = columnes.getString(18);
                nullable2.add(nullable);
                String autoin = columnes.getString(23);
                autoinc.add(autoin);

            }

            Object[] fila = new Object[tipo.size()];
            //añadir la info a la tabla

            for (int y = 0; y < tipo.size(); y++) {

                fila[y] = tipo.get(y);
            }
            Object[] filase = new Object[tipo.size()];
            //añadir la info a la tabla

            for (int y = 0; y < tipo.size(); y++) {

                filase[y] = "";
            }
            Object[] filain = new Object[tipo.size()];
            //añadir la info a la tabla

            for (int y = 0; y < tipo.size(); y++) {

                filain[y] = autoinc.get(y);
            }

            Object[] fila2 = new Object[nullable2.size()];
            //añadir la info a la tabla

            for (int y = 0; y < tipo.size(); y++) {

                fila2[y] = nullable2.get(y);
            }

            modelo.addRow(fila);
            modelo.addRow(fila2);
            modelo.addRow(filain);
            modelo2.addRow(filase);

        } catch (SQLException ex) {
            Logger.getLogger(databaseManager.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public DefaultTableModel devolvermodelo() {

        return modelo;
    }

    public DefaultTableModel devolvermodelo2() {

        return modelo2;
    }

}
